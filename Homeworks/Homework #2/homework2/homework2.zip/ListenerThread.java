package Homework2;

public interface ListenerThread
{
    void threadEnded(final Thread thread);
}

